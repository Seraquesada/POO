public interface Comparable {

   boolean esNacional();
}
