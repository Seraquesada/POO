package com.company;

public class PacienteExecption  extends Exception{

    public PacienteExecption(String message) {
        super(message);
    }

}
