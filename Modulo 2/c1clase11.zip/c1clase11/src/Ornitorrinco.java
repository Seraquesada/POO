public class Ornitorrinco extends Animal{

    public Ornitorrinco(String nombre) {
        super(nombre, 150.0);
    }

    @Override
    public void hacerRuido() {
        System.out.println("prrrrrr");
    }

    public void ponerGorra(){
        System.out.println("Me convierto en agente");
    }
}
