public class Main {

    public static void main(String[] args) {

        Animal animal = new Pato("Donald",100.0,"Blanco");

        animal = new Mono("Mojojojo",300.0);

  //      animal = new Ornitorrinco("Perry");

        Ornitorrinco ornitorrinco = (Ornitorrinco) animal;



        ornitorrinco.ponerGorra();

        animal.hacerRuido();

        animal.comer(50.0);

        System.out.println(animal.getEnergia());


    }
}