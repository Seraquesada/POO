public class Mono extends Animal{

    public Mono(String nombre, Double energia) {
        super(nombre, energia);
    }

    @Override
    public void hacerRuido() {
        System.out.println("U A A A");
    }

    @Override
    public void comer(Double energiaComida) {
        super.comer(energiaComida*2);
    }


}
