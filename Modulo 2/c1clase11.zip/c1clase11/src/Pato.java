public class Pato extends Animal{

    private String color;

    public Pato(String nombre, Double energia, String color) {
        super(nombre, energia);
        this.color = color;
    }

    @Override
    public void hacerRuido() {
        System.out.println("cuack cuack");
    }
}
