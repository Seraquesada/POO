public interface Comprable {

    public Double informarPrecio();

}
