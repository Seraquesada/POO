public class UnidadDeTrabajoException extends Exception{
    //constructor
    public UnidadDeTrabajoException(String message) {
        super(message);
    }
}
