import java.util.Objects;

public class Simple extends  EmpresaServicio{
    private Double precio;

    public Simple(String nombre, String descripccion, Double precio) {
        super(nombre, descripccion);
        this.precio = precio;
    }

    @Override
    public Double calcularPrecio() {
        if (Objects.equals(getNombre(), "Colocacion")){
            return (precio*0.10) + precio;
        }
        return precio;
    }
}
