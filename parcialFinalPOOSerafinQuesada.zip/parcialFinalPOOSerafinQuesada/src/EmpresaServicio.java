public abstract class EmpresaServicio {
    private String nombre;
    private String descripccion;

    public EmpresaServicio(String nombre, String descripccion){
        this.descripccion = descripccion;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract Double calcularPrecio();
    @Override
    public String toString() {
        return "nombre: " + nombre + " precio: " + calcularPrecio();
    }
}
