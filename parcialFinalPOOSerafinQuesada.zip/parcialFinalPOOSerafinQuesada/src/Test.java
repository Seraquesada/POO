public class Test {
    public static void main(String[] args) {

        EmpresaServicioFactory empresaServicioFactory = EmpresaServicioFactory.getInstance();

        GestionarPrecios gestionarPrecios = new GestionarPrecios();
        gestionarPrecios.agregarEmpresaServicio(empresaServicioFactory.crearEmpresaServicio(EmpresaServicioFactory.COLOCACION));
        gestionarPrecios.agregarEmpresaServicio(empresaServicioFactory.crearEmpresaServicio(EmpresaServicioFactory.VENTA_AIRE_ACONDICIONADO));
        gestionarPrecios.agregarEmpresaServicio(empresaServicioFactory.crearEmpresaServicio(EmpresaServicioFactory.COMBO));

        gestionarPrecios.mostrarInfo();
    }
}