import java.util.ArrayList;
import java.util.List;

public class GestionarPrecios {
    private List<EmpresaServicio> empresaServicioList;

    public GestionarPrecios() {
        this.empresaServicioList = new ArrayList<>();
    }

    public void mostrarInfo(){
        for (EmpresaServicio empresaServicio : empresaServicioList) {
            System.out.println(empresaServicio.toString());
        }
    }

    public void agregarEmpresaServicio(EmpresaServicio empresaServicio){
        empresaServicioList.add(empresaServicio);
    }

}
