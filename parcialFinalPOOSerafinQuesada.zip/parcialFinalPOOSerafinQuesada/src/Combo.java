import java.util.ArrayList;
import java.util.List;

public class Combo extends EmpresaServicio{
    private Double descuento;
    private List<EmpresaServicio> empresaServicioList ;

    public Combo(String nombre, String descripccion, Double descuento) {
        super(nombre, descripccion);
        this.descuento = descuento;
        this.empresaServicioList  = new ArrayList<>();
    }

    @Override
    public Double calcularPrecio() {
        Double sumaMonto = 0.0;
        for (EmpresaServicio empresaServicio : empresaServicioList) {
            sumaMonto += empresaServicio.calcularPrecio();
        }
        return sumaMonto - (sumaMonto * descuento);
    }

    public void agregarEmpresaServicio(EmpresaServicio empresaServicio){
        empresaServicioList.add(empresaServicio);
    }

}
