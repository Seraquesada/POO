public class EmpresaServicioFactory {

    public static final String  VENTA_AIRE_ACONDICIONADO = "Venta de aire acondicionado";
    public static final String COLOCACION = "Colocacion";
    public static final String COMBO = "COMBO";
    private static EmpresaServicioFactory instance;

    public static EmpresaServicioFactory getInstance() {
        if (instance == null){
            instance = new EmpresaServicioFactory();
        }
        return instance;
    }

    public EmpresaServicio crearEmpresaServicio(String codigo){
        switch (codigo){
            case VENTA_AIRE_ACONDICIONADO:
                return new Simple("Venta de aire acondicionado","venta de aires",65000.0);
            case  COLOCACION:
                return new Simple("Colocacion","Colocamos aires",10000.0);
            case COMBO:
                Combo combo = new Combo("Combo","Esto es un combo", 0.10);
                combo.agregarEmpresaServicio(crearEmpresaServicio(COLOCACION));
                combo.agregarEmpresaServicio(crearEmpresaServicio(VENTA_AIRE_ACONDICIONADO));
                return combo;
        }
        return null;
    }

}
